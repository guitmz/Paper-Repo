# pe-injection
pe injector


HOW TO RUN 

1. Open PEINJECTON.cpp
2. change the parameters cuz cmd arguements are a meme and change the string
3. ctrl f5 or save and run exe 
3. big hacker



WHAT DOES THIS DO? 
relocates a source executable to run inside of a target. This is a good feature to have inside of a malicous program or a cheat because you can then theoretically hijack a process handle that is of importance or whatever. 


WHY IS THIS DIFFERENT FROM OTHER PE INJECTORS? 
It uses classes and from the sources i used to make this they didnt have them like this. So i can theoretically write a program to create more than one object and call for different processes and they can inject at the same time.
